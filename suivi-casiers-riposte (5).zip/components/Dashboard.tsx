import React, { useMemo } from 'react';
import { LockerItem, LockerStatus } from '../types';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Legend } from 'recharts';
import { STATUS_COLORS, STATUS_LABELS } from '../constants';
import { AlertTriangle, CheckCircle, Clock, Package } from 'lucide-react';

interface DashboardProps {
  lockers: LockerItem[];
}

export const Dashboard: React.FC<DashboardProps> = ({ lockers }) => {
  const stats = useMemo(() => {
    const counts = {
      total: lockers.length,
      bloque: 0,
      pdc: 0,
      libourne: 0,
      dispo: 0
    };

    lockers.forEach(l => {
      if (l.status === LockerStatus.BLOQUE) counts.bloque++;
      else if (l.status === LockerStatus.ENVOIE_PDC) counts.pdc++;
      else if (l.status === LockerStatus.ENVOIE_LIBOURNE) counts.libourne++;
      else if (l.status === LockerStatus.DISPONIBLE) counts.dispo++;
    });

    return counts;
  }, [lockers]);

  const pieData = [
    { name: 'Bloqué', value: stats.bloque, color: '#ef4444' }, // red-500
    { name: 'Envoie PDC', value: stats.pdc, color: '#f97316' }, // orange-500
    { name: 'Libourne', value: stats.libourne, color: '#3b82f6' }, // blue-500
    { name: 'Dispo', value: stats.dispo, color: '#10b981' }, // emerald-500
  ].filter(d => d.value > 0);

  const StatCard = ({ title, value, icon: Icon, colorClass }: any) => (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 hover:shadow-md transition-shadow">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-bold text-slate-500 uppercase tracking-wider">{title}</h3>
        <div className={`p-2 rounded-full ${colorClass.replace('text-', 'bg-').replace('700', '100')} bg-opacity-20`}>
          <Icon className={colorClass} size={20} />
        </div>
      </div>
      <div className="flex items-baseline">
        <span className="text-4xl font-display font-bold text-slate-800">{value}</span>
        <span className="ml-2 text-sm text-slate-400 font-medium">Casiers</span>
      </div>
    </div>
  );

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <h2 className="text-2xl font-bold text-slate-800 font-display border-l-4 border-indigo-500 pl-4">TABLEAU DE BORD</h2>
      
      {/* Cards Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard title="Total Casiers" value={stats.total} icon={Package} colorClass="text-indigo-600" />
        <StatCard title="Bloqués" value={stats.bloque} icon={AlertTriangle} colorClass="text-red-600" />
        <StatCard title="En Attente PDC" value={stats.pdc} icon={Clock} colorClass="text-orange-600" />
        <StatCard title="Env. Libourne" value={stats.libourne} icon={CheckCircle} colorClass="text-blue-600" />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Status Distribution */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
          <h3 className="text-lg font-bold text-slate-700 mb-6 font-display">Répartition des Statuts</h3>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                />
                <Legend verticalAlign="bottom" height={36} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Alerts / Recent Activity Panel */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 flex flex-col">
          <h3 className="text-lg font-bold text-slate-700 mb-4 font-display flex items-center">
            <AlertTriangle className="text-red-500 mr-2" size={20} />
            Alertes Prioritaires
          </h3>
          <div className="flex-1 overflow-y-auto pr-2 space-y-3">
             {lockers.filter(l => l.status === LockerStatus.BLOQUE).length === 0 && (
                <div className="text-center text-slate-400 py-10">Aucune alerte pour le moment.</div>
             )}
             {lockers.filter(l => l.status === LockerStatus.BLOQUE).map(item => (
               <div key={item.id} className="flex items-start p-3 bg-red-50 rounded-lg border border-red-100">
                  <div className="flex-1">
                    <p className="font-bold text-red-800 text-sm">{item.lockerNumber} - {item.clientName}</p>
                    <p className="text-xs text-red-600 mt-1">{item.observation || "Aucune observation"}</p>
                    <p className="text-[10px] text-red-400 mt-2 font-mono uppercase">Déposé le: {new Date(item.depositDate).toLocaleDateString()}</p>
                  </div>
                  <span className="px-2 py-1 bg-white text-red-600 text-[10px] font-bold rounded border border-red-200 uppercase">
                    Bloqué
                  </span>
               </div>
             ))}
          </div>
        </div>
      </div>
    </div>
  );
};
