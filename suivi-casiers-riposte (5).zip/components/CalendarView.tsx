
import React, { useState, useMemo } from 'react';
import { LockerItem, LockerStatus } from '../types';
import { ChevronLeft, ChevronRight, X, CircleDot, Truck } from 'lucide-react';

interface CalendarViewProps {
  lockers: LockerItem[];
}

// Helper function to format date for comparison
const formatDate = (date: Date) => date.toISOString().split('T')[0];

export const CalendarView: React.FC<CalendarViewProps> = ({ lockers }) => {
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedDay, setSelectedDay] = useState<Date | null>(null);

  const daysInMonth = (date: Date) => new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  const firstDayOfMonth = (date: Date) => new Date(date.getFullYear(), date.getMonth(), 1).getDay(); // 0 for Sunday, 1 for Monday

  // Adjust first day of month to start on Monday (0) instead of Sunday (0)
  const getStartDay = (date: Date) => {
    const day = firstDayOfMonth(date);
    return day === 0 ? 6 : day - 1; // Convert Sunday (0) to 6 (end of week)
  };

  const weekdays = ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'];
  const monthNames = [
    'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', // Corrected: Added 'Avril'
    'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'
  ];

  const calendarDays = useMemo(() => {
    const numDays = daysInMonth(currentMonth);
    const startDay = getStartDay(currentMonth);
    const prevMonthDays = daysInMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1, 1));

    const days: Array<{ date: Date; isCurrentMonth: boolean }> = [];

    // Days from previous month
    for (let i = startDay - 1; i >= 0; i--) {
      days.push({
        date: new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1, prevMonthDays - i),
        isCurrentMonth: false,
      });
    }

    // Days of current month
    for (let i = 1; i <= numDays; i++) {
      days.push({
        date: new Date(currentMonth.getFullYear(), currentMonth.getMonth(), i),
        isCurrentMonth: true,
      });
    }

    // Days from next month (to fill the grid)
    const remainingCells = 42 - days.length; // Max 6 weeks * 7 days
    for (let i = 1; i <= remainingCells; i++) {
      days.push({
        date: new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, i),
        isCurrentMonth: false,
      });
    }

    return days;
  }, [currentMonth]);

  const eventsMap = useMemo(() => {
    const map = new Map<string, { deposits: LockerItem[]; departures: LockerItem[] }>();
    lockers.forEach(locker => {
      // Deposit date
      const depositDateFormatted = formatDate(new Date(locker.depositDate));
      if (!map.has(depositDateFormatted)) {
        map.set(depositDateFormatted, { deposits: [], departures: [] });
      }
      map.get(depositDateFormatted)?.deposits.push(locker);

      // Departure date
      if (locker.departureDate) {
        const departureDateFormatted = formatDate(new Date(locker.departureDate));
        if (!map.has(departureDateFormatted)) {
          map.set(departureDateFormatted, { deposits: [], departures: [] });
        }
        map.get(departureDateFormatted)?.departures.push(locker);
      }
    });
    return map;
  }, [lockers]);

  const getDayEvents = (day: Date) => {
    const formattedDay = formatDate(day);
    return eventsMap.get(formattedDay) || { deposits: [], departures: [] };
  };

  const goToPreviousMonth = () => {
    setCurrentMonth(prev => new Date(prev.getFullYear(), prev.getMonth() - 1, 1));
  };

  const goToNextMonth = () => {
    setCurrentMonth(prev => new Date(prev.getFullYear(), prev.getMonth() + 1, 1));
  };

  const isToday = (date: Date) => formatDate(date) === formatDate(new Date());

  const handleDayClick = (day: Date) => {
    setSelectedDay(day);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <h2 className="text-2xl font-bold text-slate-800 font-display border-l-4 border-indigo-500 pl-4">
        CALENDRIER DES CASIERS
      </h2>

      <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-6 max-w-4xl mx-auto">
        {/* Calendar Header */}
        <div className="flex items-center justify-between mb-6">
          <button onClick={goToPreviousMonth} className="p-2 rounded-full hover:bg-slate-100 transition-colors text-slate-600">
            <ChevronLeft size={20} />
          </button>
          <h3 className="text-xl font-bold text-slate-800 font-display">
            {monthNames[currentMonth.getMonth()]} {currentMonth.getFullYear()}
          </h3>
          <button onClick={goToNextMonth} className="p-2 rounded-full hover:bg-slate-100 transition-colors text-slate-600">
            <ChevronRight size={20} />
          </button>
        </div>

        {/* Weekday Headers */}
        <div className="grid grid-cols-7 gap-1 text-center text-sm font-semibold text-slate-500 mb-2">
          {weekdays.map(day => (
            <div key={day} className="py-2">{day}</div>
          ))}
        </div>

        {/* Calendar Grid */}
        <div className="grid grid-cols-7 gap-1">
          {calendarDays.map((dayObj, index) => {
            const { date, isCurrentMonth } = dayObj;
            const { deposits, departures } = getDayEvents(date);
            const hasDeposits = deposits.length > 0;
            const hasDepartures = departures.length > 0;

            return (
              <button
                key={index}
                onClick={() => handleDayClick(date)}
                className={`
                  h-24 p-1 rounded-lg flex flex-col items-center justify-between relative
                  ${isCurrentMonth ? 'text-slate-800 hover:bg-indigo-50' : 'text-slate-400 opacity-60'}
                  ${isToday(date) ? 'bg-indigo-100 border border-indigo-300' : 'bg-slate-50 hover:bg-slate-100'}
                  transition-colors duration-150
                  ${hasDeposits || hasDepartures ? 'font-bold' : ''}
                `}
              >
                <span className={`text-sm ${isToday(date) ? 'text-indigo-700 font-extrabold' : ''}`}>
                  {date.getDate()}
                </span>
                <div className="flex flex-col items-center gap-1 mt-auto">
                  {hasDeposits && (
                    <span className="w-2 h-2 bg-emerald-500 rounded-full" title={`${deposits.length} dépôt(s)`}></span>
                  )}
                  {hasDepartures && (
                    <span className="w-2 h-2 bg-orange-500 rounded-full" title={`${departures.length} départ(s)`}></span>
                  )}
                  {(hasDeposits || hasDepartures) && (
                      <span className="text-xs text-slate-600">
                          {deposits.length + departures.length}
                      </span>
                  )}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Day Details Modal */}
      {selectedDay && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="p-4 bg-slate-900 flex justify-between items-center">
              <h3 className="text-white font-bold font-display tracking-wider">
                DÉTAILS DU {selectedDay.toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
              </h3>
              <button onClick={() => setSelectedDay(null)} className="text-slate-400 hover:text-white">
                <X size={20} />
              </button>
            </div>

            <div className="p-6 max-h-[70vh] overflow-y-auto">
              {(() => {
                const { deposits, departures } = getDayEvents(selectedDay);
                const hasEvents = deposits.length > 0 || departures.length > 0;

                return (
                  <div className="space-y-6">
                    {!hasEvents && (
                      <p className="text-slate-500 text-center py-8">Aucun événement pour ce jour.</p>
                    )}

                    {deposits.length > 0 && (
                      <div>
                        <h4 className="flex items-center text-emerald-700 font-bold mb-3 border-b border-emerald-100 pb-2">
                          <CircleDot size={18} className="mr-2" />
                          Dépôts ({deposits.length})
                        </h4>
                        <ul className="space-y-2">
                          {deposits.map(locker => (
                            <li key={locker.id} className="bg-emerald-50 border border-emerald-100 p-3 rounded-lg flex justify-between items-center text-sm">
                              <div>
                                <p className="font-semibold text-emerald-800">{locker.clientName}</p>
                                <p className="text-xs text-emerald-600 font-mono">{locker.lockerNumber} - {locker.location}</p>
                              </div>
                              <span className="px-2 py-1 bg-white text-emerald-600 text-xs font-bold rounded-full">Dépôt</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {departures.length > 0 && (
                      <div>
                        <h4 className="flex items-center text-orange-700 font-bold mb-3 border-b border-orange-100 pb-2">
                          <Truck size={18} className="mr-2" />
                          Départs ({departures.length})
                        </h4>
                        <ul className="space-y-2">
                          {departures.map(locker => (
                            <li key={locker.id} className="bg-orange-50 border border-orange-100 p-3 rounded-lg flex justify-between items-center text-sm">
                              <div>
                                <p className="font-semibold text-orange-800">{locker.clientName}</p>
                                <p className="text-xs text-orange-600 font-mono">{locker.lockerNumber} - {locker.location}</p>
                              </div>
                              <span className="px-2 py-1 bg-white text-orange-600 text-xs font-bold rounded-full">Départ</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                );
              })()}
            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-100">
              <button onClick={() => setSelectedDay(null)} className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-3 rounded-xl font-bold transition-colors">
                FERMER
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};