
import React, { useState, useEffect } from 'react';
import { LayoutDashboard, List, PlusCircle, Settings, LogOut, Box, BookOpen, Download, Laptop, History } from 'lucide-react'; // CalendarDays icon removed

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onLogout: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab, onLogout }) => {
  const [installPrompt, setInstallPrompt] = useState<any>(null);
  const [isInstalled, setIsInstalled] = useState(false);

  useEffect(() => {
    // Check if already installed
    if (window.matchMedia('(display-mode: standalone)').matches) {
      setIsInstalled(true);
    }

    // Capture the install prompt
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setInstallPrompt(e);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  // Fix: Define handleInstallClick function
  const handleInstallClick = async () => {
    if (!installPrompt) {
        console.log('No install prompt found.');
        return;
    }
    // Show the install prompt
    installPrompt.prompt();
    // Wait for the user to respond to the prompt
    const { outcome } = await installPrompt.userChoice;
    // The user either accepted or dismissed the PWA install prompt.
    if (outcome === 'accepted') {
        console.log('User accepted the PWA install prompt');
        setIsInstalled(true); // Mark as installed
    } else {
        console.log('User dismissed the PWA install prompt');
    }
    // We no longer need the prompt, so clear it
    setInstallPrompt(null);
  };

  const menuItems = [
    { id: 'add', label: 'Nouveau Client', icon: PlusCircle },
    { id: 'dashboard', label: 'Tableau de Bord', icon: LayoutDashboard },
    { id: 'list', label: 'Liste des Casiers', icon: List },
    // { id: 'calendar', label: 'Calendrier', icon: CalendarDays }, // Nouveau - Removed as requested
    { id: 'history', label: 'Historique', icon: History },
    { id: 'guide', label: 'Guide Utilisation', icon: BookOpen },
    { id: 'settings', label: 'Paramètres', icon: Settings },
  ];

  return (
    <div className="w-64 bg-slate-900 text-white flex flex-col h-full shadow-xl fixed left-0 top-0 z-20 hidden md:flex">
      <div className="p-6 flex items-center space-x-3 border-b border-slate-800">
        <div className="p-2 bg-indigo-500 rounded-lg">
          <Box size={24} className="text-white" />
        </div>
        <div>
          <h1 className="font-bold text-lg leading-tight tracking-wide font-display">RIPOSTE</h1>
          <p className="text-xs text-slate-400">Suivi Casiers</p>
        </div>
      </div>

      <nav className="flex-1 py-6 px-3 space-y-1">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 group ${
                isActive
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-900/20'
                  : 'text-slate-400 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <Icon size={20} className={isActive ? 'text-white' : 'text-slate-500 group-hover:text-white'} />
              <span className="font-medium tracking-wide">{item.label}</span>
            </button>
          );
        })}
      </nav>

      <div className="px-4 pb-4">
        {!isInstalled && (
          <button
              onClick={handleInstallClick}
              className="w-full bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white py-3 px-4 rounded-lg flex items-center justify-center space-x-2 transition-all group mb-2 shadow-md border border-indigo-400/30"
          >
              {installPrompt ? (
                 <Download size={18} className="group-hover:-translate-y-1 transition-transform" />
              ) : (
                 <Laptop size={18} />
              )}
              <span className="text-xs font-bold uppercase tracking-wider">
                INSTALLER SUR PC
              </span>
          </button>
        )}
      </div>

      <div className="p-4 border-t border-slate-800">
        <button
          onClick={onLogout}
          className="flex items-center space-x-3 px-4 py-3 w-full text-slate-400 hover:text-red-400 hover:bg-slate-800 rounded-lg transition-colors"
        >
          <LogOut size={20} />
          <span>Déconnexion</span>
        </button>
        <div className="mt-4 text-center">
          <p className="text-[10px] text-slate-600 uppercase tracking-widest">
            Créé par Bouzid Cherif
          </p>
        </div>
      </div>
    </div>
  );
};
