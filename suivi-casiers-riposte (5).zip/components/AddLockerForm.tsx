
import React, { useState, useEffect, useRef } from 'react';
import { LockerItem, LockerStatus } from '../types';
import { Save, X, Upload, Trash2 } from 'lucide-react';
import { useToast } from './ToastManager';
import { DatePicker } from './DatePicker';

interface AddLockerFormProps {
  onSubmit: (item: LockerItem) => void;
  onCancel: () => void;
  initialData?: LockerItem | null;
}

const InputGroup = ({ label, children }: { label: string; children?: React.ReactNode }) => (
  <div className="space-y-1">
    <label className="text-xs font-bold text-slate-500 uppercase tracking-wider font-display">{label}</label>
    {children}
  </div>
);

// Max file size for Base64 storage (e.g., 5MB)
const MAX_FILE_SIZE_MB = 5; 
const MAX_FILE_SIZE_BYTES = MAX_FILE_SIZE_MB * 1024 * 1024;

export const AddLockerForm: React.FC<AddLockerFormProps> = ({ onSubmit, onCancel, initialData }) => {
  const [formData, setFormData] = useState<Partial<LockerItem>>({
    clientName: '',
    lockerNumber: '',
    depositDate: new Date().toISOString().split('T')[0],
    status: LockerStatus.DISPONIBLE,
    location: '',
    observation: '',
    departureDate: '',
    vdNumber: '',
    attachmentFileName: undefined,
    attachmentData: undefined, // New field for Base64 content
  });

  const [localFileName, setLocalFileName] = useState<string | undefined>(undefined);
  // Fix: Import useRef from 'react'
  const fileInputRef = useRef<HTMLInputElement>(null); // Ref to clear file input

  const { showToast } = useToast();

  useEffect(() => {
    if (initialData) {
        setFormData({
            ...initialData,
            depositDate: initialData.depositDate.split('T')[0],
            departureDate: initialData.departureDate ? initialData.departureDate.split('T')[0] : ''
        });
        setLocalFileName(initialData.attachmentFileName);
    }
  }, [initialData]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.clientName || !formData.lockerNumber || !formData.depositDate) {
        showToast('Le nom du client, le numéro de casier et la date de dépôt sont obligatoires.', 'error');
        return;
    };

    const newItem: LockerItem = {
      id: initialData?.id || crypto.randomUUID(),
      clientName: formData.clientName!,
      lockerNumber: formData.lockerNumber!,
      depositDate: new Date(formData.depositDate!).toISOString(),
      status: formData.status as LockerStatus,
      location: formData.location || '',
      observation: formData.observation || '',
      departureDate: formData.departureDate ? new Date(formData.departureDate).toISOString() : undefined,
      vdNumber: formData.vdNumber || '',
      attachmentFileName: localFileName,
      attachmentData: formData.attachmentData, // Include Base64 data
    };

    onSubmit(newItem);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
        const file = e.target.files[0];

        if (file.size > MAX_FILE_SIZE_BYTES) {
            showToast(`Le fichier est trop volumineux (max ${MAX_FILE_SIZE_MB}Mo).`, 'error');
            if (fileInputRef.current) fileInputRef.current.value = ""; // Clear file input
            setLocalFileName(undefined);
            setFormData(prev => ({ ...prev, attachmentData: undefined }));
            return;
        }

        const reader = new FileReader();
        reader.onloadend = () => {
            setLocalFileName(file.name);
            setFormData(prev => ({ ...prev, attachmentData: reader.result as string }));
            showToast(`Fichier "${file.name}" sélectionné !`, 'info');
        };
        reader.onerror = () => {
            showToast('Erreur de lecture du fichier.', 'error');
            setLocalFileName(undefined);
            setFormData(prev => ({ ...prev, attachmentData: undefined }));
        };
        reader.readAsDataURL(file); // Read file as Base64
    }
  };

  const removeFile = () => {
      setLocalFileName(undefined);
      setFormData(prev => ({ ...prev, attachmentData: undefined }));
      if (fileInputRef.current) fileInputRef.current.value = ""; // Clear file input
      showToast('Pièce jointe supprimée', 'info');
  };
  
  return (
    <div className="bg-white p-8 rounded-2xl shadow-xl max-w-2xl mx-auto border border-slate-100 animate-in zoom-in-95 duration-300">
      <div className="flex justify-between items-center mb-8 border-b border-slate-100 pb-4">
        <h2 className="text-2xl font-bold text-slate-800 font-display">
            {initialData ? 'MODIFIER CASIER' : 'NOUVEAU CLIENT / CASIER'}
        </h2>
        <button onClick={onCancel} className="text-slate-400 hover:text-slate-600 transition-colors">
            <X size={24} />
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <InputGroup label="Nom du Client *">
            <input
              required
              type="text"
              className="w-full p-3 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all font-medium"
              placeholder="Ex: Entreprise X"
              value={formData.clientName}
              onChange={e => setFormData({ ...formData, clientName: e.target.value })}
            />
          </InputGroup>

          <InputGroup label="Numéro Casier *">
            <input
              required
              type="text"
              className="w-full p-3 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all font-mono font-bold"
              placeholder="Ex: A-100"
              value={formData.lockerNumber}
              onChange={e => setFormData({ ...formData, lockerNumber: e.target.value })}
            />
          </InputGroup>

          {/* Date de Dépôt using new DatePicker component */}
          <DatePicker
            label="Date de Dépôt *"
            value={formData.depositDate || ''}
            onChange={date => setFormData({ ...formData, depositDate: date })}
            required
          />

          <InputGroup label="Statut">
            <select
              className="w-full p-3 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all font-medium"
              value={formData.status}
              onChange={e => setFormData({ ...formData, status: e.target.value as LockerStatus })}
            >
              {Object.values(LockerStatus).map(status => (
                <option key={status} value={status}>{status}</option>
              ))}
            </select>
          </InputGroup>

          <InputGroup label="Emplacement">
             <input
              type="text"
              className="w-full p-3 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all"
              placeholder="Ex: Zone B, Étagère 2"
              value={formData.location}
              onChange={e => setFormData({ ...formData, location: e.target.value })}
            />
          </InputGroup>

          <InputGroup label="Numéro VD">
             <input
              type="text"
              className="w-full p-3 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all font-mono"
              placeholder="Ex: VD-123456"
              value={formData.vdNumber}
              onChange={e => setFormData({ ...formData, vdNumber: e.target.value })}
            />
          </InputGroup>

          {/* Date de Départ using new DatePicker component */}
          <DatePicker
            label="Date de Départ (Optionnel)"
            value={formData.departureDate || ''}
            onChange={date => setFormData({ ...formData, departureDate: date })}
          />
        </div>

        <InputGroup label="Observations">
          <textarea
            rows={3}
            className="w-full p-3 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all resize-none"
            placeholder="Détails supplémentaires, état, instructions..."
            value={formData.observation}
            onChange={e => setFormData({ ...formData, observation: e.target.value })}
          />
        </InputGroup>

        <div className="p-4 bg-slate-50 rounded-lg border border-slate-200 border-dashed">
            <div className="flex items-center justify-between">
                <div>
                    <label className="text-xs font-bold text-slate-500 uppercase tracking-wider font-display block mb-1">Pièce Jointe (Max {MAX_FILE_SIZE_MB}Mo)</label>
                    <p className="text-xs text-slate-400">Photos, documents PDF, etc.</p>
                </div>
                <div>
                    <input 
                        type="file" 
                        id="file-upload" 
                        className="hidden" 
                        onChange={handleFileChange}
                        ref={fileInputRef} // Add ref to clear input
                    />
                    {!localFileName ? (
                        <label 
                            htmlFor="file-upload"
                            className="cursor-pointer flex items-center space-x-2 px-4 py-2 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors text-slate-600 text-sm font-medium shadow-sm"
                        >
                            <Upload size={16} />
                            <span>Ajouter</span>
                        </label>
                    ) : (
                        <div className="flex items-center space-x-3 bg-indigo-50 px-3 py-2 rounded-lg border border-indigo-100">
                            <span className="text-sm text-indigo-700 font-medium truncate max-w-[150px]">{localFileName}</span>
                            <button type="button" onClick={removeFile} className="text-indigo-400 hover:text-red-500">
                                <Trash2 size={16} />
                            </button>
                        </div>
                    )}
                </div>
            </div>
        </div>

        <div className="flex space-x-4 pt-4">
            <button
                type="button"
                onClick={onCancel}
                className="flex-1 py-3 border border-slate-200 text-slate-600 rounded-xl font-bold hover:bg-slate-50 transition-colors"
            >
                ANNULER
            </button>
            <button
                type="submit"
                className="flex-1 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 shadow-lg shadow-indigo-900/20 hover:shadow-indigo-900/40 transition-all flex items-center justify-center space-x-2"
            >
                <Save size={18} />
                <span>ENREGISTRER</span>
            </button>
        </div>
      </form>
    </div>
  );
};