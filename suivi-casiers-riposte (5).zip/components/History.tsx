

import React, { useState, useEffect } from 'react';
import { LogEntry } from '../types';
import { getLogs } from '../services/storageService';
import { History as HistoryIcon, Activity, Clock, FileText, Trash2, RefreshCw, Archive } from 'lucide-react'; // Added Archive icon

export const History: React.FC = () => {
  const [logs, setLogs] = useState<LogEntry[]>([]);

  useEffect(() => {
    setLogs(getLogs());
  }, []);

  const getIcon = (type: LogEntry['actionType']) => {
      switch(type) {
          case 'CREATION': return <FileText size={16} className="text-emerald-500" />;
          case 'SUPPRESSION_DEFINITIVE': return <Trash2 size={16} className="text-red-500" />;
          case 'ARCHIVAGE': return <Archive size={16} className="text-orange-500" />;
          case 'STATUT': return <RefreshCw size={16} className="text-blue-500" />;
          default: return <Activity size={16} className="text-slate-500" />;
      }
  };

  const getLabel = (type: LogEntry['actionType']) => {
    switch(type) {
      case 'CREATION': return 'CRÉATION';
      case 'MODIFICATION': return 'MODIFICATION';
      case 'ARCHIVAGE': return 'ARCHIVAGE';
      case 'SUPPRESSION_DEFINITIVE': return 'SUPPRESSION DÉFINITIVE';
      case 'STATUT': return 'CHANGEMENT STATUT';
      default: return 'ACTIVITÉ';
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <h2 className="text-2xl font-bold text-slate-800 font-display border-l-4 border-indigo-500 pl-4">
          HISTORIQUE D'ACTIVITÉ
      </h2>

      <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
        {logs.length === 0 ? (
             <div className="p-12 text-center text-slate-400 flex flex-col items-center">
                 <HistoryIcon size={48} className="mb-4 opacity-20" />
                 <p>Aucune activité récente enregistrée.</p>
             </div>
        ) : (
            <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                    <thead>
                        <tr className="bg-slate-50 border-b border-slate-200 text-xs font-bold text-slate-500 uppercase tracking-wider font-display">
                            <th className="p-4">Date</th>
                            <th className="p-4">Action</th>
                            <th className="p-4">Cible (Casier)</th>
                            <th className="p-4">Détails</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                        {logs.map((log) => (
                            <tr key={log.id} className="hover:bg-slate-50 transition-colors">
                                <td className="p-4 text-sm text-slate-500 font-mono whitespace-nowrap">
                                    {new Date(log.date).toLocaleString('fr-FR')}
                                </td>
                                <td className="p-4">
                                    <div className="flex items-center gap-2">
                                        <div className="p-1.5 rounded-full bg-slate-100">
                                            {getIcon(log.actionType)}
                                        </div>
                                        <span className="text-xs font-bold text-slate-700">{getLabel(log.actionType)}</span>
                                    </div>
                                </td>
                                <td className="p-4 text-sm font-bold text-slate-800">
                                    {log.target}
                                </td>
                                <td className="p-4 text-sm text-slate-600">
                                    {log.description}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        )}
      </div>
    </div>
  );
};