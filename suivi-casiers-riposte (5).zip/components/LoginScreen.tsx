
import React, { useState, useEffect } from 'react';
import { Box, Lock, ArrowRight, Eye, EyeOff } from 'lucide-react'; // Added Eye, EyeOff

interface LoginScreenProps {
  onLogin: (password: string) => boolean;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin }) => {
  const [password, setPassword] = useState('');
  const [error, setError] = useState(false);
  const [animate, setAnimate] = useState(false);
  const [showPassword, setShowPassword] = useState(false); // New state for password visibility

  useEffect(() => {
    setAnimate(true);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!onLogin(password)) {
      setError(true);
      setTimeout(() => setError(false), 1000);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background Decor - Enhanced */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0">
         <div className="absolute -top-40 -left-40 w-[500px] h-[500px] bg-indigo-700 rounded-full mix-blend-screen filter blur-3xl opacity-10 animate-pulse-slow" style={{animationDelay: '0s'}}></div>
         <div className="absolute -bottom-60 -right-60 w-[600px] h-[600px] bg-blue-600 rounded-full mix-blend-screen filter blur-3xl opacity-10 animate-pulse-slow" style={{animationDelay: '2s'}}></div>
         <div className="absolute top-1/2 left-1/4 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] bg-purple-700 rounded-full mix-blend-screen filter blur-3xl opacity-5 animate-pulse-slow" style={{animationDelay: '4s'}}></div>
      </div>

      <div className={`
        bg-white/5 backdrop-blur-3xl p-8 md:p-12 rounded-3xl shadow-2xl border border-white/20 w-full max-w-md z-10 
        transition-all duration-1000 transform 
        ${animate ? 'translate-y-0 opacity-100 scale-100' : 'translate-y-10 opacity-0 scale-95'}
      `}>
        
        <div className="text-center mb-10">
          <div className={`inline-flex items-center justify-center w-24 h-24 rounded-2xl bg-gradient-to-br from-indigo-500 to-blue-600 shadow-xl mb-6 
            transform hover:scale-105 transition-transform duration-300 ${animate ? 'animate-fade-in-up-bounce' : ''}`}>
            <Box size={50} className="text-white drop-shadow-lg" />
          </div>
          <h1 className="text-4xl font-extrabold text-white mb-2 font-display tracking-wide drop-shadow-md">
            SUIVI CASIERS <br/>
            <span className="bg-gradient-to-r from-indigo-300 to-blue-400 text-transparent bg-clip-text">RIPOSTE</span>
          </h1>
          <p className="text-slate-400 text-sm mt-3">Authentifiez-vous pour accéder au système.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="relative group">
            <Lock className="absolute left-4 top-1/2 transform -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-400 transition-colors" size={20} />
            <input
              type={showPassword ? 'text' : 'password'} // Toggle input type
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className={`
                w-full bg-slate-800/70 border ${error ? 'border-red-500' : 'border-slate-700 group-focus-within:border-indigo-500'} 
                text-white rounded-xl py-4 pl-12 pr-12 
                focus:outline-none focus:ring-2 focus:ring-indigo-400 focus:shadow-md 
                transition-all placeholder-slate-500 font-semibold text-lg
              `}
              placeholder="Mot de passe sécurisé"
              aria-label="Mot de passe"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-4 top-1/2 transform -translate-y-1/2 text-slate-400 hover:text-indigo-400 transition-colors"
              aria-label={showPassword ? 'Masquer le mot de passe' : 'Afficher le mot de passe'}
            >
              {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
            </button>
          </div>

          <button
            type="submit"
            className="
              w-full bg-gradient-to-r from-indigo-700 to-blue-700 hover:from-indigo-600 hover:to-blue-600 text-white 
              font-bold py-4 rounded-xl shadow-xl shadow-indigo-900/60 hover:shadow-blue-900/60 
              transition-all duration-300 flex items-center justify-center group
            "
          >
            <span className="text-lg">ACCÉDER AU SYSTÈME</span>
            <ArrowRight className="ml-3 transform group-hover:translate-x-1 transition-transform" size={20} />
          </button>
        </form>

        <div className="mt-10 text-center space-y-2">
            <p className="text-xs text-slate-500 uppercase tracking-widest opacity-80">
              Système de Gestion de Stockage Avancé
            </p>
            <p className="text-xs text-indigo-400/70 font-bold uppercase tracking-widest">
              Conçu et Développé par Bouzid Cherif
            </p>
        </div>
      </div>

      {/* Custom Tailwind CSS keyframes */}
      <style>{`
        @keyframes pulse-slow {
          0%, 100% { transform: scale(1); opacity: 0.1; }
          50% { transform: scale(1.05); opacity: 0.15; }
        }
        .animate-pulse-slow { animation: pulse-slow 6s infinite ease-in-out alternate; }

        @keyframes fade-in-up-bounce {
            0% { opacity: 0; transform: translateY(30px) scale(0.8); }
            60% { opacity: 1; transform: translateY(-5px) scale(1.05); }
            100% { transform: translateY(0) scale(1); }
        }
        .animate-fade-in-up-bounce { animation: fade-in-up-bounce 0.9s ease-out forwards; }
      `}</style>
    </div>
  );
};