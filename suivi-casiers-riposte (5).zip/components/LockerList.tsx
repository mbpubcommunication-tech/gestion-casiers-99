

import React, { useState, useRef } from 'react';
import { LockerItem, LockerStatus } from '../types';
import { STATUS_COLORS, STATUS_LABELS } from '../constants';
import { Search, Filter, Paperclip, Trash2, Edit, Download, AlertCircle, FileText, QrCode, X, Printer, AlertTriangle, Archive, HardDrive } from 'lucide-react'; // Added Archive, HardDrive
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";
import QRCode from "react-qr-code";
import { useToast } from './ToastManager';

interface LockerListProps {
  lockers: LockerItem[];
  onDelete: (item: LockerItem) => void; // Now takes LockerItem to determine archive/delete
  onEdit: (item: LockerItem) => void;
}

export const LockerList: React.FC<LockerListProps> = ({ lockers, onDelete, onEdit }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [showArchived, setShowArchived] = useState<boolean>(false); // New state for archived lockers
  const [qrItem, setQrItem] = useState<LockerItem | null>(null);
  const [itemToDelete, setItemToDelete] = useState<LockerItem | null>(null);

  const { showToast } = useToast();

  const filteredLockers = lockers.filter(item => {
    const matchesSearch = 
      item.clientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.lockerNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (item.vdNumber && item.vdNumber.toLowerCase().includes(searchTerm.toLowerCase()));
    
    // Filter by status, excluding archived unless showArchived is true
    const matchesStatus = statusFilter === 'ALL' || item.status === statusFilter;
    const isArchived = item.status === LockerStatus.ARCHIVE;

    return matchesSearch && matchesStatus && (showArchived || !isArchived);
  });

  const isLate = (dateString: string) => {
      const deposit = new Date(dateString);
      const now = new Date();
      const diffTime = Math.abs(now.getTime() - deposit.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 
      return diffDays > 30; // Alert if more than 30 days
  };

  const handleExportCSV = () => {
      const headers = ['ID', 'Client', 'Casier', 'Date Dépôt', 'Statut', 'Emplacement', 'Observation', 'Numéro VD', 'Pièce Jointe'];
      const csvContent = [
          headers.join(';'),
          ...filteredLockers.map(item => [
              item.id,
              `"${item.clientName}"`,
              item.lockerNumber,
              new Date(item.depositDate).toLocaleDateString('fr-FR'),
              item.status,
              `"${item.location}"`,
              `"${item.observation}"`,
              item.vdNumber || '',
              item.attachmentFileName || '' // Only filename, not data
          ].join(';'))
      ].join('\n');

      const blob = new Blob(["\uFEFF" + csvContent], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = `Export_Casiers_${new Date().toISOString().slice(0,10)}.csv`;
      link.click();
      showToast('Export CSV réussi !', 'success');
  };

  const handleExportPDF = () => {
    const doc = new jsPDF();

    doc.setFontSize(20);
    doc.setTextColor(79, 70, 229);
    doc.text("Suivi Casiers Riposte", 14, 20);

    doc.setFontSize(10);
    doc.setTextColor(100);
    const dateStr = new Date().toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' });
    doc.text(`Rapport généré le ${dateStr}`, 14, 28);

    const total = filteredLockers.length;
    const blocked = filteredLockers.filter(l => l.status === LockerStatus.BLOQUE).length;
    doc.text(`Total: ${total} dossier(s) | Bloqués: ${blocked}`, 14, 34);

    const tableColumn = ["Casier", "Client", "Date Dépôt", "Statut", "Emplacement", "Observation", "N° VD", "Pièce Jointe"];
    const tableRows = filteredLockers.map(item => [
      item.lockerNumber,
      item.clientName,
      new Date(item.depositDate).toLocaleDateString('fr-FR'),
      item.status,
      item.location,
      item.observation,
      item.vdNumber || '-',
      item.attachmentFileName ? 'Oui' : 'Non'
    ]);

    autoTable(doc, {
      head: [tableColumn],
      body: tableRows,
      startY: 40,
      styles: { fontSize: 8, cellPadding: 3 },
      headStyles: { fillColor: [79, 70, 229], textColor: 255, fontStyle: 'bold' },
      alternateRowStyles: { fillColor: [245, 247, 250] },
      columnStyles: {
        0: { fontStyle: 'bold', cellWidth: 20 },
        3: { fontStyle: 'bold' },
        5: { cellWidth: 40 }
      }
    });

    doc.save(`Rapport_Casiers_${new Date().toISOString().slice(0,10)}.pdf`);
    showToast('Export PDF réussi !', 'success');
  };

  const handlePrintLabel = () => {
    window.print();
  };

  const confirmDeleteAction = () => {
    if (itemToDelete) {
        onDelete(itemToDelete); // Pass the entire item
        setItemToDelete(null);
    }
  };

  const handleViewAttachment = (item: LockerItem) => {
    if (item.attachmentData && item.attachmentFileName) {
        try {
            // Decode Base64 and create a Blob
            const byteCharacters = atob(item.attachmentData.split(',')[1]); // Remove data:mime/type;base64, prefix
            const byteNumbers = new Array(byteCharacters.length);
            for (let i = 0; i < byteCharacters.length; i++) {
                byteNumbers[i] = byteCharacters.charCodeAt(i);
            }
            const byteArray = new Uint8Array(byteNumbers);
            const blob = new Blob([byteArray], { type: item.attachmentData.split(';')[0].split(':')[1] });

            // Create a URL and open in new tab
            const url = URL.createObjectURL(blob);
            window.open(url, '_blank');
            URL.revokeObjectURL(url); // Clean up the object URL after use
            showToast(`Ouverture de "${item.attachmentFileName}"`, 'info');
        } catch (error) {
            console.error('Error viewing attachment:', error);
            showToast('Impossible d\'ouvrir la pièce jointe.', 'error');
        }
    } else {
        showToast('Aucune pièce jointe à visualiser.', 'error');
    }
  };


  return (
    <div className="space-y-6 animate-in fade-in duration-500">
       
       {/* QR Code Modal */}
       {qrItem && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 no-print">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm overflow-hidden animate-in zoom-in-95 duration-200">
                <div className="p-4 bg-slate-900 flex justify-between items-center">
                    <h3 className="text-white font-bold font-display tracking-wider">ÉTIQUETTE CASIER</h3>
                    <button onClick={() => setQrItem(null)} className="text-slate-400 hover:text-white">
                        <X size={20} />
                    </button>
                </div>
                
                <div id="printable-area" className="p-8 flex flex-col items-center text-center bg-white">
                    <div className="border-2 border-black p-4 rounded-lg mb-4 bg-white">
                        <QRCode 
                            value={`Casier: ${qrItem.lockerNumber}\nClient: ${qrItem.clientName}\nStatut: ${qrItem.status}\nEmplacement: ${qrItem.location}`}
                            size={150}
                        />
                    </div>
                    <h2 className="text-3xl font-bold text-slate-900 font-display mb-1">{qrItem.lockerNumber}</h2>
                    <p className="text-lg font-semibold text-slate-700 mb-4">{qrItem.clientName}</p>
                    
                    <div className="w-full border-t border-slate-100 pt-4 text-left space-y-1 text-sm text-slate-500">
                        <p><strong>Statut:</strong> {qrItem.status}</p>
                        <p><strong>Emp:</strong> {qrItem.location}</p>
                        <p><strong>Date:</strong> {new Date(qrItem.depositDate).toLocaleDateString('fr-FR')}</p>
                    </div>
                </div>

                <div className="p-4 bg-slate-50 border-t border-slate-100 flex gap-3">
                    <button 
                        onClick={handlePrintLabel} 
                        className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white py-3 rounded-xl font-bold flex items-center justify-center gap-2 transition-colors"
                    >
                        <Printer size={18} />
                        IMPRIMER
                    </button>
                </div>
            </div>
        </div>
       )}

       {/* Delete/Archive Confirmation Modal */}
       {itemToDelete && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 no-print">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden animate-in zoom-in-95 duration-200">
                <div className="p-6 text-center">
                    <div className={`mx-auto w-16 h-16 rounded-full flex items-center justify-center mb-4 
                        ${itemToDelete.status === LockerStatus.ARCHIVE ? 'bg-red-100' : 'bg-orange-100'}`}>
                        {itemToDelete.status === LockerStatus.ARCHIVE ? (
                            <Trash2 className="text-red-600" size={32} />
                        ) : (
                            <Archive className="text-orange-600" size={32} />
                        )}
                    </div>
                    <h3 className="text-xl font-bold text-slate-900 mb-2 font-display">
                        {itemToDelete.status === LockerStatus.ARCHIVE ? 'Confirmer la suppression définitive' : 'Confirmer l\'archivage'}
                    </h3>
                    <p className="text-slate-500 text-sm leading-relaxed">
                        {itemToDelete.status === LockerStatus.ARCHIVE ? (
                            <>Êtes-vous sûr de vouloir supprimer définitivement le casier <strong className="text-slate-800">{itemToDelete.lockerNumber}</strong> de <strong className="text-slate-800">{itemToDelete.clientName}</strong> ?<br/>Cette action est irréversible et effacera toutes les données.</>
                        ) : (
                            <>Êtes-vous sûr de vouloir archiver le casier <strong className="text-slate-800">{itemToDelete.lockerNumber}</strong> de <strong className="text-slate-800">{itemToDelete.clientName}</strong> ?<br/>Il sera déplacé vers les archives mais pourra être restauré.</>
                        )}
                    </p>
                </div>
                <div className="p-4 bg-slate-50 border-t border-slate-100 flex gap-3">
                    <button 
                        onClick={() => setItemToDelete(null)}
                        className="flex-1 py-3 border border-slate-200 text-slate-700 rounded-xl font-bold hover:bg-white transition-colors"
                    >
                        ANNULER
                    </button>
                    <button 
                        onClick={confirmDeleteAction} 
                        className={`flex-1 py-3 rounded-xl font-bold flex items-center justify-center gap-2 transition-colors shadow-lg 
                            ${itemToDelete.status === LockerStatus.ARCHIVE ? 'bg-red-600 hover:bg-red-700 shadow-red-900/20' : 'bg-orange-600 hover:bg-orange-700 shadow-orange-900/20'} text-white`}
                    >
                        {itemToDelete.status === LockerStatus.ARCHIVE ? <Trash2 size={18} /> : <Archive size={18} />}
                        {itemToDelete.status === LockerStatus.ARCHIVE ? 'SUPPRIMER DÉFINITIVEMENT' : 'ARCHIVER'}
                    </button>
                </div>
            </div>
        </div>
       )}

       {/* Hidden Printable Area for Browser Print */}
       {qrItem && (
           <div className="print-only fixed top-0 left-0 w-full h-full bg-white flex items-center justify-center z-[100]">
               <div className="flex flex-col items-center justify-center text-center border-4 border-black p-8 rounded-xl max-w-[80mm]">
                    <h1 className="text-4xl font-bold font-display mb-2">{qrItem.lockerNumber}</h1>
                    <div className="mb-4">
                         <QRCode 
                            value={`C:${qrItem.lockerNumber}|${qrItem.clientName}`}
                            size={120}
                        />
                    </div>
                    <p className="text-xl font-bold mb-2 uppercase">{qrItem.clientName}</p>
                    <p className="text-sm">{qrItem.location}</p>
                    <p className="text-xs mt-2">{new Date().toLocaleDateString()}</p>
               </div>
           </div>
       )}

       <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 no-print">
        <h2 className="text-2xl font-bold text-slate-800 font-display border-l-4 border-indigo-500 pl-4">LISTE DES CASIERS</h2>
        
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400" size={18} />
            <input
              type="text"
              placeholder="Rechercher client, casier..."
              className="pl-10 pr-4 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 w-full text-sm"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <div className="relative">
            <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400" size={18} />
            <select
              className="pl-10 pr-8 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 appearance-none bg-white text-sm font-medium text-slate-600 w-full sm:w-auto"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            >
              <option value="ALL">Tous les statuts</option>
              {Object.values(LockerStatus).map(status => (
                <option key={status} value={status}>{status}</option>
              ))}
            </select>
          </div>

          {/* Toggle for archived items */}
          <button
              onClick={() => setShowArchived(!showArchived)}
              className={`flex items-center justify-center space-x-2 px-4 py-2 rounded-lg transition-colors shadow-sm text-sm font-bold
                ${showArchived ? 'bg-slate-700 text-white hover:bg-slate-600' : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200'}`}
              title={showArchived ? "Masquer les casiers archivés" : "Afficher les casiers archivés"}
          >
              <HardDrive size={18} />
              <span className="hidden xl:inline">{showArchived ? 'Actifs' : 'Archivés'}</span>
          </button>

          <div className="flex space-x-2">
            <button 
              onClick={handleExportCSV}
              className="flex-1 sm:flex-none flex items-center justify-center space-x-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg transition-colors shadow-sm text-sm font-bold"
              title="Exporter en Excel (CSV)"
            >
              <Download size={18} />
              <span className="hidden xl:inline">CSV</span>
            </button>
            <button 
              onClick={handleExportPDF}
              className="flex-1 sm:flex-none flex items-center justify-center space-x-2 px-4 py-2 bg-red-600 hover:bg-red-500 text-white rounded-lg transition-colors shadow-sm text-sm font-bold"
              title="Exporter en PDF"
            >
              <FileText size={18} />
              <span className="hidden xl:inline">PDF</span>
            </button>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden no-print">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200">
                <th className="p-4 text-xs font-bold text-slate-500 uppercase tracking-wider font-display">Client</th>
                <th className="p-4 text-xs font-bold text-slate-500 uppercase tracking-wider font-display">Casier</th>
                <th className="p-4 text-xs font-bold text-slate-500 uppercase tracking-wider font-display">Dépôt</th>
                <th className="p-4 text-xs font-bold text-slate-500 uppercase tracking-wider font-display">Statut</th>
                <th className="p-4 text-xs font-bold text-slate-500 uppercase tracking-wider font-display">Emplacement</th>
                <th className="p-4 text-xs font-bold text-slate-500 uppercase tracking-wider font-display">Obs.</th>
                <th className="p-4 text-xs font-bold text-slate-500 uppercase tracking-wider font-display text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredLockers.length === 0 ? (
                 <tr>
                   <td colSpan={8} className="p-8 text-center text-slate-400 italic">Aucun casier trouvé.</td>
                 </tr>
              ) : filteredLockers.map((item) => {
                const late = isLate(item.depositDate) && item.status !== LockerStatus.DISPONIBLE && item.status !== LockerStatus.ARCHIVE;
                return (
                <tr key={item.id} className={`hover:bg-slate-50 transition-colors group ${late ? 'bg-red-50/30' : ''} ${item.status === LockerStatus.ARCHIVE ? 'opacity-70 italic' : ''}`}>
                  <td className="p-4">
                    <div className="font-bold text-slate-800">{item.clientName}</div>
                  </td>
                  <td className="p-4 font-mono text-slate-600 font-bold">{item.lockerNumber}</td>
                  <td className="p-4 text-sm text-slate-600 font-medium">
                    <div className="flex items-center">
                        {new Date(item.depositDate).toLocaleDateString('fr-FR')}
                        {late && (
                            <div className="ml-2 text-red-500" title="Dépôt supérieur à 30 jours">
                                <AlertCircle size={14} />
                            </div>
                        )}
                    </div>
                  </td>
                  <td className="p-4">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wide border ${STATUS_COLORS[item.status]}`}>
                      {STATUS_LABELS[item.status]}
                    </span>
                  </td>
                  <td className="p-4 text-sm text-slate-600">{item.location}</td>
                  <td className="p-4">
                    <div className="text-xs text-slate-500 max-w-[150px] truncate" title={item.observation}>
                      {item.observation || "-"}
                    </div>
                  </td>
                  <td className="p-4 text-center">
                     <div className="flex items-center justify-center space-x-2">
                        <button 
                            onClick={() => setQrItem(item)}
                            className="text-slate-400 hover:text-slate-800 transition-colors p-1 rounded hover:bg-slate-100"
                            title="Générer Étiquette QR"
                        >
                            <QrCode size={16} />
                        </button>
                        {item.attachmentFileName && item.attachmentData && (
                            <button 
                                onClick={() => handleViewAttachment(item)}
                                className="text-indigo-400 hover:text-indigo-600 transition-colors p-1 rounded hover:bg-indigo-50"
                                title={`Voir: ${item.attachmentFileName}`}
                            >
                                <Paperclip size={16} />
                            </button>
                        )}
                        <button onClick={() => onEdit(item)} className="text-slate-400 hover:text-indigo-600 transition-colors p-1 rounded hover:bg-indigo-50" title="Modifier">
                          <Edit size={16} />
                        </button>
                        <button 
                            onClick={() => setItemToDelete(item)} 
                            className={`p-1 rounded ${item.status === LockerStatus.ARCHIVE ? 'text-red-400 hover:text-red-600 hover:bg-red-50' : 'text-orange-400 hover:text-orange-600 hover:bg-orange-50'} transition-colors`}
                            title={item.status === LockerStatus.ARCHIVE ? 'Supprimer Définitivement' : 'Archiver'}
                        >
                            {item.status === LockerStatus.ARCHIVE ? <Trash2 size={16} /> : <Archive size={16} />}
                        </button>
                     </div>
                  </td>
                </tr>
              )})}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};