
import React, { useState, useEffect } from 'react';
import { createRoot } from 'react-dom/client';
import { LockerItem, LockerStatus, UserSettings } from './types';
import { getLockers, addLocker, updateLocker, getSettings, saveSettings, archiveLocker, permanentlyDeleteLocker } from './services/storageService'; // Updated imports
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';
import { LockerList } from './components/LockerList';
import { AddLockerForm } from './components/AddLockerForm';
import { LoginScreen } from './components/LoginScreen';
import { UserGuide } from './components/UserGuide';
import { History } from './components/History';
import { Settings as SettingsIcon, Save } from 'lucide-react';
import { WelcomeScreen } from './components/WelcomeScreen'; 
import { ToastProvider, useToast } from './components/ToastManager';

const AppContent: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [lockers, setLockers] = useState<LockerItem[]>([]);
  const [settings, setSettings] = useState<UserSettings | null>(null);
  const [editingItem, setEditingItem] = useState<LockerItem | null>(null);
  const [showWelcomeScreen, setShowWelcomeScreen] = useState(true); 
  
  // Settings State
  const [tempPassword, setTempPassword] = useState('');

  const { showToast } = useToast();

  useEffect(() => {
    setLockers(getLockers());
    setSettings(getSettings());
  }, []);

  const handleLogin = (inputPassword: string) => {
    const currentSettings = getSettings();
    if (inputPassword === currentSettings.password) {
      setIsAuthenticated(true);
      return true;
    }
    showToast('Mot de passe incorrect', 'error');
    return false;
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setActiveTab('dashboard');
    showToast('Déconnexion réussie', 'info');
  };

  const handleAddLocker = (item: LockerItem) => {
    if (editingItem) {
        setLockers(updateLocker(item));
        setEditingItem(null);
        showToast(`Casier ${item.lockerNumber} mis à jour !`, 'success');
    } else {
        setLockers(addLocker(item));
        showToast(`Casier ${item.lockerNumber} ajouté !`, 'success');
    }
    setActiveTab('list');
  };

  // Updated handleDeleteLocker to handle archive vs permanent delete
  const handleDeleteLocker = (item: LockerItem) => {
    if (item.status === LockerStatus.ARCHIVE) {
        setLockers(permanentlyDeleteLocker(item.id));
        showToast(`Casier ${item.lockerNumber} supprimé définitivement !`, 'success');
    } else {
        setLockers(archiveLocker(item.id));
        showToast(`Casier ${item.lockerNumber} archivé !`, 'info');
    }
  };

  const handleEditInit = (item: LockerItem) => {
      setEditingItem(item);
      setActiveTab('add');
  };

  const handleSaveSettings = (e: React.FormEvent) => {
      e.preventDefault();
      if(tempPassword && settings) {
          const newSettings = {...settings, password: tempPassword};
          saveSettings(newSettings);
          setSettings(newSettings);
          showToast('Mot de passe mis à jour !', 'success');
          setTempPassword('');
      } else {
          showToast('Veuillez entrer un nouveau mot de passe.', 'error');
      }
  };

  if (showWelcomeScreen) {
    return <WelcomeScreen onStart={() => setShowWelcomeScreen(false)} />;
  }

  if (!isAuthenticated) {
    return <LoginScreen onLogin={handleLogin} />;
  }

  return (
    <div className="flex min-h-screen bg-slate-50">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} onLogout={handleLogout} />

      <main className="flex-1 md:ml-64 p-6 lg:p-10 overflow-x-hidden">
        {activeTab === 'dashboard' && <Dashboard lockers={lockers} />}
        
        {activeTab === 'list' && (
          <LockerList 
            lockers={lockers} 
            onDelete={handleDeleteLocker} 
            onEdit={handleEditInit}
          />
        )}
        
        {activeTab === 'add' && (
          <div className="flex justify-center pt-10">
            <AddLockerForm 
                onSubmit={handleAddLocker} 
                onCancel={() => {
                    setEditingItem(null);
                    setActiveTab('list');
                }}
                initialData={editingItem}
            />
          </div>
        )}

        {/* {activeTab === 'calendar' && <CalendarView lockers={lockers} />} */}

        {activeTab === 'history' && <History />}
        {activeTab === 'guide' && <UserGuide />}

        {activeTab === 'settings' && (
            <div className="max-w-xl mx-auto bg-white p-8 rounded-2xl shadow-lg border border-slate-100 animate-in fade-in duration-500">
                <div className="flex items-center mb-6 text-slate-700">
                    <SettingsIcon className="mr-3" />
                    <h2 className="text-2xl font-bold font-display">Paramètres</h2>
                </div>
                <form onSubmit={handleSaveSettings} className="space-y-4">
                    <div>
                        <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Nouveau mot de passe</label>
                        <input 
                            type="text" 
                            value={tempPassword}
                            onChange={(e) => setTempPassword(e.target.value)}
                            placeholder="Entrez le nouveau mot de passe"
                            className="w-full p-3 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                        />
                    </div>
                    <button type="submit" className="flex items-center justify-center w-full py-3 bg-slate-900 text-white rounded-lg font-bold hover:bg-indigo-600 transition-colors">
                        <Save size={18} className="mr-2"/>
                        Enregistrer
                    </button>
                </form>
                <div className="mt-8 pt-8 border-t border-slate-100 text-center">
                    <p className="text-slate-400 text-sm">Application Suivi Casiers Riposte v1.2</p>
                    <p className="text-slate-400 text-sm font-bold mt-1">Créé par Bouzid Cherif</p>
                </div>
            </div>
        )}
      </main>
    </div>
  );
};

const App: React.FC = () => (
  <ToastProvider>
    <AppContent />
  </ToastProvider>
);

export default App;