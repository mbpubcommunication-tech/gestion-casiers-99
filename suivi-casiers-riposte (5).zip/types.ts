

export enum LockerStatus {
  BLOQUE = 'Bloqué',
  ENVOIE_PDC = 'Envoie PDC',
  ENVOIE_LIBOURNE = 'Envoie Libourne',
  DISPONIBLE = 'Disponible',
  ARCHIVE = 'Archivé'
}

export interface LockerItem {
  id: string;
  clientName: string;
  lockerNumber: string;
  depositDate: string; // ISO string
  status: LockerStatus;
  location: string;
  observation: string;
  departureDate?: string; // ISO string
  vdNumber?: string;
  attachmentFileName?: string; // Change from hasAttachment: boolean
  attachmentData?: string; // Base64 encoded string of the attachment file
}

export interface UserSettings {
  password: string;
  appName: string;
}

export interface DashboardStats {
  total: number;
  bloque: number;
  pdc: number;
  libourne: number;
  available: number;
}

export interface LogEntry {
  id: string;
  date: string;
  actionType: 'CREATION' | 'MODIFICATION' | 'ARCHIVAGE' | 'SUPPRESSION_DEFINITIVE' | 'STATUT'; // Updated action types
  description: string;
  target: string; // Numéro de casier ou Client
}

// New type for Toast messages
export type ToastType = 'success' | 'error' | 'info';

export interface ToastMessage {
  id: string;
  message: string;
  type: ToastType;
}