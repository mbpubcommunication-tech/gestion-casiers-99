
const CACHE_NAME = 'riposte-cache-v2'; // Bump cache version for changes
const urlsToCache = [
  '/',
  '/index.html',
  '/manifest.json'
];

// Install event - cache basic assets
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        return cache.addAll(urlsToCache);
      })
      .then(() => self.skipWaiting()) // Force new service worker to activate immediately
  );
});

// Activate event - clean up old caches and claim clients
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME) {
            console.log('Deleting old cache:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    }).then(() => {
      // Ensure that the new service worker takes control of existing clients immediately
      return self.clients.claim();
    })
  );
});

// Fetch event - Cache-first for navigation requests (HTML pages), Network-first for others
self.addEventListener('fetch', (event) => {
  // Check if it's a navigation request (e.g., loading the main page of the PWA)
  // or a direct request for index.html.
  const isHtmlPage = event.request.mode === 'navigate' || event.request.url.includes('/index.html');

  if (isHtmlPage) {
    // Cache-first strategy for HTML pages:
    // Try to serve from cache. If not found, fetch from network and then cache the response.
    event.respondWith(
      caches.match(event.request)
        .then(response => {
          // If cached, return the cached version.
          if (response) {
            return response;
          }
          // If not in cache, fetch from network.
          return fetch(event.request)
            .then(networkResponse => {
              // Cache the new network response for future use.
              return caches.open(CACHE_NAME).then(cache => {
                cache.put(event.request, networkResponse.clone());
                return networkResponse;
              });
            })
            .catch(() => {
              // If network fails (e.g., offline) and not in cache, return a fallback.
              // This ensures index.html is always returned if possible for navigation.
              return caches.match('/index.html');
            });
        })
    );
  } else {
    // For all other requests (e.g., JS, CSS, images, API calls): Network-first strategy
    // Try to fetch from network. If network fails (e.g., offline), fall back to cache.
    event.respondWith(
      fetch(event.request).catch(() => {
        return caches.match(event.request);
      })
    );
  }
});