import React from 'react';
import { LayoutDashboard, List, PlusCircle, Search, Settings, Monitor, CheckCircle2 } from 'lucide-react';

export const UserGuide: React.FC = () => {
  return (
    <div className="space-y-8 animate-in fade-in duration-500 max-w-5xl mx-auto pb-10">
       <div className="border-l-4 border-indigo-500 pl-4 mb-8">
        <h2 className="text-2xl font-bold text-slate-800 font-display uppercase">Guide d'Utilisation</h2>
        <p className="text-slate-500 mt-1">Documentation complète pour la gestion des casiers Riposte</p>
      </div>

      {/* Installation Section - Highlighted */}
      <div className="bg-gradient-to-br from-slate-800 to-slate-900 text-white p-8 rounded-xl shadow-xl border border-slate-700">
        <div className="flex items-center mb-6 text-indigo-400">
            <Monitor className="mr-3" size={28} />
            <h3 className="font-bold font-display text-xl uppercase tracking-wide">Installation sur Windows (PC)</h3>
        </div>
        <p className="text-slate-300 mb-6 leading-relaxed">
            Pour utiliser <strong>Suivi Casiers Riposte</strong> comme un logiciel Windows classique (fichier .exe), utilisez la fonction d'installation native de votre navigateur. Cela créera une icône sur votre bureau et lancera le logiciel dans une fenêtre dédiée, sans barre d'adresse.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
             <div className="bg-white/5 p-4 rounded-lg border border-white/10 hover:bg-white/10 transition-colors">
                <div className="flex items-center mb-3">
                    <div className="w-8 h-8 rounded-full bg-indigo-600 flex items-center justify-center font-bold text-white mr-3">1</div>
                    <span className="font-bold text-indigo-200">Navigateur</span>
                </div>
                <p className="text-xs text-slate-400">Ouvrez cette application avec <strong>Google Chrome</strong> ou <strong>Microsoft Edge</strong>.</p>
             </div>
             <div className="bg-white/5 p-4 rounded-lg border border-white/10 hover:bg-white/10 transition-colors">
                <div className="flex items-center mb-3">
                    <div className="w-8 h-8 rounded-full bg-indigo-600 flex items-center justify-center font-bold text-white mr-3">2</div>
                    <span className="font-bold text-indigo-200">Menu</span>
                </div>
                <p className="text-xs text-slate-400">Cliquez sur les <strong>...</strong> en haut à droite, puis cherchez <strong>"Installer l'application"</strong> ou "Applications".</p>
             </div>
             <div className="bg-white/5 p-4 rounded-lg border border-white/10 hover:bg-white/10 transition-colors">
                <div className="flex items-center mb-3">
                    <div className="w-8 h-8 rounded-full bg-emerald-600 flex items-center justify-center font-bold text-white mr-3">
                        <CheckCircle2 size={16} />
                    </div>
                    <span className="font-bold text-emerald-200">Installé !</span>
                </div>
                <p className="text-xs text-slate-400">Une icône est créée sur votre bureau. Le logiciel se lance maintenant comme une application native.</p>
             </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Dashboard */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
            <div className="flex items-center mb-4 text-indigo-600">
                <LayoutDashboard className="mr-2" />
                <h3 className="font-bold font-display text-lg uppercase">1. Tableau de Bord</h3>
            </div>
            <p className="text-slate-600 text-sm leading-relaxed mb-3">
                Le tableau de bord offre une vue d'ensemble instantanée de l'état du stockage.
            </p>
            <ul className="list-disc list-inside text-sm text-slate-500 space-y-2">
                <li><span className="font-bold text-slate-700">Indicateurs :</span> Total des casiers, casiers bloqués, envois PDC et Libourne.</li>
                <li><span className="font-bold text-slate-700">Graphique :</span> Visualisation rapide de la répartition des statuts.</li>
                <li><span className="font-bold text-slate-700">Alertes :</span> Liste prioritaire des casiers bloqués nécessitant une attention immédiate.</li>
            </ul>
        </div>

        {/* Nouveau Casier */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
            <div className="flex items-center mb-4 text-emerald-600">
                <PlusCircle className="mr-2" />
                <h3 className="font-bold font-display text-lg uppercase">2. Ajouter un Client</h3>
            </div>
            <p className="text-slate-600 text-sm leading-relaxed mb-3">
                Utilisez le menu "Nouveau Client" pour enregistrer une entrée.
            </p>
            <ul className="list-disc list-inside text-sm text-slate-500 space-y-2">
                <li>Remplissez les champs obligatoires (*).</li>
                <li>Sélectionnez le statut (ex: Disponible, Bloqué).</li>
                <li>Indiquez l'emplacement précis pour faciliter le retrouvé.</li>
                <li>Ajoutez des pièces jointes (photos, bordereaux) si nécessaire.</li>
            </ul>
        </div>

        {/* Liste et Actions */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
            <div className="flex items-center mb-4 text-blue-600">
                <List className="mr-2" />
                <h3 className="font-bold font-display text-lg uppercase">3. Gestion & Suivi</h3>
            </div>
            <p className="text-slate-600 text-sm leading-relaxed mb-3">
                La liste des casiers est le cœur de votre gestion quotidienne.
            </p>
            <ul className="list-disc list-inside text-sm text-slate-500 space-y-2">
                <li><span className="font-bold text-slate-700">Modifier :</span> Cliquez sur l'icône crayon pour changer un statut ou ajouter une note.</li>
                <li><span className="font-bold text-slate-700">Supprimer :</span> Utilisez l'icône poubelle pour archiver ou supprimer une entrée.</li>
                <li><span className="font-bold text-slate-700">Détails :</span> Visualisez les numéros VD et dates de départ.</li>
            </ul>
        </div>

        {/* Recherche */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
             <div className="flex items-center mb-4 text-orange-600">
                <Search className="mr-2" />
                <h3 className="font-bold font-display text-lg uppercase">4. Recherche & Filtres</h3>
            </div>
            <p className="text-slate-600 text-sm leading-relaxed mb-3">
                Retrouvez rapidement n'importe quel dossier grâce aux outils de tri.
            </p>
            <ul className="list-disc list-inside text-sm text-slate-500 space-y-2">
                <li><span className="font-bold text-slate-700">Recherche intelligente :</span> Par nom de client, numéro de casier ou numéro VD.</li>
                <li><span className="font-bold text-slate-700">Filtres :</span> Triez la liste par statut (ex: afficher uniquement les "Envoie PDC").</li>
            </ul>
        </div>
      </div>

      <div className="bg-slate-50 border border-slate-200 text-slate-600 p-8 rounded-xl mt-8">
          <div className="flex flex-col md:flex-row items-start md:items-center md:space-x-6 space-y-4 md:space-y-0">
             <div className="p-3 bg-white shadow-sm rounded-lg">
                <Settings className="text-slate-400" size={32} />
             </div>
             <div>
                 <h3 className="font-bold font-display text-lg uppercase mb-2 text-slate-800">Paramètres & Support</h3>
                 <p className="text-slate-500 text-sm">
                     Le mot de passe par défaut est <strong>1234</strong>. Vous pouvez le modifier à tout moment dans l'onglet Paramètres pour sécuriser l'accès à l'application.
                 </p>
             </div>
          </div>
          <div className="mt-6 pt-6 border-t border-slate-200 text-center md:text-right">
              <p className="text-xs text-slate-400 uppercase tracking-widest font-bold">
                  Application développée par Bouzid Cherif
              </p>
          </div>
      </div>
    </div>
  );
};