

import { LockerItem, UserSettings, LockerStatus, LogEntry } from '../types';
import { DEFAULT_PASSWORD } from '../constants';

const LOCKERS_KEY = 'riposte_lockers_data';
const SETTINGS_KEY = 'riposte_settings_data';
const LOGS_KEY = 'riposte_logs_data';


// Mock Initial Data
const INITIAL_LOCKERS: LockerItem[] = [
  {
    id: '1',
    clientName: 'Jean Dupont',
    lockerNumber: 'A-102',
    depositDate: new Date(Date.now() - 86400000 * 40).toISOString(), // 40 days ago
    status: LockerStatus.BLOQUE,
    location: 'Zone Nord',
    observation: 'Problème de clé',
    vdNumber: 'VD-9921',
    attachmentFileName: 'rapport_incident_A102.pdf',
  },
  {
    id: '2',
    clientName: 'Sophie Martin',
    lockerNumber: 'B-204',
    depositDate: new Date(Date.now() - 86400000 * 3).toISOString(), // 3 days ago
    status: LockerStatus.ENVOIE_PDC,
    location: 'Zone Sud',
    observation: 'En attente validation',
    attachmentFileName: undefined,
  },
  {
    id: '3',
    clientName: 'Archives S.A.',
    lockerNumber: 'Z-001',
    depositDate: new Date(Date.now() - 86400000 * 100).toISOString(), // 100 days ago
    status: LockerStatus.ARCHIVE,
    location: 'Entrepôt F',
    observation: 'Ancien casier, client parti.',
    attachmentFileName: 'contrat_archive_Z001.pdf',
  }
];

export const getLockers = (): LockerItem[] => {
  const data = localStorage.getItem(LOCKERS_KEY);
  if (!data) {
    localStorage.setItem(LOCKERS_KEY, JSON.stringify(INITIAL_LOCKERS));
    return INITIAL_LOCKERS;
  }
  return JSON.parse(data);
};

export const saveLockers = (lockers: LockerItem[]): void => {
  localStorage.setItem(LOCKERS_KEY, JSON.stringify(lockers));
};

// LOGGING SYSTEM
export const getLogs = (): LogEntry[] => {
    const data = localStorage.getItem(LOGS_KEY);
    return data ? JSON.parse(data) : [];
};

const addLog = (actionType: LogEntry['actionType'], description: string, target: string) => {
    const logs = getLogs();
    const newLog: LogEntry = {
        id: crypto.randomUUID(),
        date: new Date().toISOString(),
        actionType,
        description,
        target
    };
    // Keep only last 200 logs to save space
    const updatedLogs = [newLog, ...logs].slice(0, 200);
    localStorage.setItem(LOGS_KEY, JSON.stringify(updatedLogs));
};

export const addLocker = (locker: LockerItem): LockerItem[] => {
  const current = getLockers();
  const updated = [locker, ...current];
  saveLockers(updated);
  addLog('CREATION', `Nouveau dépôt pour ${locker.clientName}`, locker.lockerNumber);
  return updated;
};

export const updateLocker = (locker: LockerItem): LockerItem[] => {
  const current = getLockers();
  const oldItem = current.find(l => l.id === locker.id);
  const updated = current.map((l) => (l.id === locker.id ? locker : l));
  
  saveLockers(updated);

  if (oldItem && oldItem.status !== locker.status) {
      addLog('STATUT', `Changement: ${oldItem.status} ➔ ${locker.status}`, locker.lockerNumber);
  } else {
      addLog('MODIFICATION', `Mise à jour des informations`, locker.lockerNumber);
  }
  
  return updated;
};

export const archiveLocker = (id: string): LockerItem[] => {
  const current = getLockers();
  const itemToArchive = current.find(l => l.id === id);
  if (itemToArchive) {
      const updated = current.map(l => 
          l.id === id ? { ...l, status: LockerStatus.ARCHIVE, departureDate: new Date().toISOString() } : l
      );
      saveLockers(updated);
      addLog('ARCHIVAGE', `Casier archivé`, itemToArchive.lockerNumber);
      return updated;
  }
  return current;
};

export const permanentlyDeleteLocker = (id: string): LockerItem[] => {
  const current = getLockers();
  const itemToDelete = current.find(l => l.id === id);
  const updated = current.filter((l) => l.id !== id);
  saveLockers(updated);
  
  if (itemToDelete) {
      addLog('SUPPRESSION_DEFINITIVE', `Casier supprimé définitivement`, itemToDelete.lockerNumber);
  }
  
  return updated;
};


export const getSettings = (): UserSettings => {
  const data = localStorage.getItem(SETTINGS_KEY);
  if (!data) {
    const defaultSettings: UserSettings = {
      password: DEFAULT_PASSWORD,
      appName: 'Suivi Casiers Riposte',
    };
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(defaultSettings));
    return defaultSettings;
  }
  return JSON.parse(data);
};

export const saveSettings = (settings: UserSettings): void => {
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
};