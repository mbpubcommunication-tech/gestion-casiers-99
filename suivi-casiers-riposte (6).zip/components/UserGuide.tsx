
import React from 'react';
import { LayoutDashboard, List, PlusCircle, Search, Settings, Monitor, CheckCircle2, Laptop, Download } from 'lucide-react';

export const UserGuide: React.FC = () => {
  return (
    <div className="space-y-8 animate-in fade-in duration-500 max-w-5xl mx-auto pb-10">
       <div className="border-l-4 border-indigo-500 pl-4 mb-8">
        <h2 className="text-2xl font-bold text-slate-800 font-display uppercase">Guide d'Utilisation</h2>
        <p className="text-slate-500 mt-1">Comment installer l'application sur votre PC Windows</p>
      </div>

      {/* Installation Section - Updated for Windows PC */}
      <div className="bg-gradient-to-br from-slate-800 to-slate-900 text-white p-8 rounded-xl shadow-xl border border-slate-700">
        <div className="flex items-center mb-6 text-indigo-400">
            <Monitor className="mr-3" size={28} />
            <h3 className="font-bold font-display text-xl uppercase tracking-wide">Installer sur PC (Windows)</h3>
        </div>
        <p className="text-slate-300 mb-8 leading-relaxed">
            Cette application utilise la technologie PWA (Progressive Web App). Elle ne nécessite pas de fichier <code>.exe</code> traditionnel. Une fois installée via le navigateur, elle fonctionne exactement comme un logiciel natif (icône bureau, fenêtre dédiée, mode hors ligne).
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Section PC - Chrome/Edge */}
            <div className="bg-white/5 p-6 rounded-xl border-2 border-indigo-500/30 hover:border-indigo-500 transition-colors relative overflow-hidden group">
                <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                    <Laptop size={80} />
                </div>
                <div className="flex items-center mb-4 text-white">
                    <Laptop className="mr-2" />
                    <h4 className="font-bold text-lg">Méthode Automatique</h4>
                </div>
                <div className="space-y-4">
                    <p className="text-sm text-slate-300">C'est la méthode la plus simple si le bouton est disponible.</p>
                    <ol className="list-decimal list-inside text-sm text-slate-300 space-y-2">
                        <li>Regardez le menu de gauche de cette application.</li>
                        <li>Cliquez sur le bouton <strong>"INSTALLER SUR PC"</strong>.</li>
                        <li>Validez la confirmation qui s'affiche à l'écran.</li>
                    </ol>
                     <div className="bg-emerald-900/40 p-3 rounded border border-emerald-500/30 text-xs text-emerald-200 flex items-start">
                        <CheckCircle2 size={14} className="mr-2 mt-0.5 shrink-0"/>
                        <span>Une icône <strong>Riposte</strong> est ajoutée sur votre bureau et dans le menu Démarrer.</span>
                    </div>
                </div>
            </div>

            {/* Section PC - Manuel */}
            <div className="bg-white/5 p-6 rounded-xl border border-white/10 hover:bg-white/10 transition-colors relative overflow-hidden group">
                <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                    <Download size={80} />
                </div>
                <div className="flex items-center mb-4 text-white">
                    <Download className="mr-2" />
                    <h4 className="font-bold text-lg">Méthode Manuelle</h4>
                </div>
                 <div className="space-y-4">
                    <p className="text-sm text-slate-300">Si le bouton n'apparaît pas, suivez ces étapes dans <strong>Chrome</strong> ou <strong>Edge</strong> :</p>
                    <ol className="list-decimal list-inside text-sm text-slate-300 space-y-2">
                        <li>Regardez tout en haut à droite de votre navigateur (dans la barre d'adresse).</li>
                        <li>Vous verrez une petite icône <Download size={14} className="inline mx-1"/> ou un <strong>(+)</strong>.</li>
                        <li>Cliquez dessus et choisissez <strong>"Installer Suivi Casiers Riposte"</strong>.</li>
                    </ol>
                </div>
            </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Dashboard */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
            <div className="flex items-center mb-4 text-indigo-600">
                <LayoutDashboard className="mr-2" />
                <h3 className="font-bold font-display text-lg uppercase">1. Tableau de Bord</h3>
            </div>
            <p className="text-slate-600 text-sm leading-relaxed mb-3">
                Le tableau de bord offre une vue d'ensemble instantanée de l'état du stockage.
            </p>
            <ul className="list-disc list-inside text-sm text-slate-500 space-y-2">
                <li><span className="font-bold text-slate-700">Indicateurs :</span> Total des casiers, casiers bloqués, envois PDC et Libourne.</li>
                <li><span className="font-bold text-slate-700">Graphique :</span> Visualisation rapide de la répartition des statuts.</li>
                <li><span className="font-bold text-slate-700">Alertes :</span> Liste prioritaire des casiers bloqués nécessitant une attention immédiate.</li>
            </ul>
        </div>

        {/* Nouveau Casier */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
            <div className="flex items-center mb-4 text-emerald-600">
                <PlusCircle className="mr-2" />
                <h3 className="font-bold font-display text-lg uppercase">2. Ajouter un Client</h3>
            </div>
            <p className="text-slate-600 text-sm leading-relaxed mb-3">
                Utilisez le menu "Nouveau Client" pour enregistrer une entrée.
            </p>
            <ul className="list-disc list-inside text-sm text-slate-500 space-y-2">
                <li>Remplissez les champs obligatoires (*).</li>
                <li>Sélectionnez le statut (ex: Disponible, Bloqué).</li>
                <li>Indiquez l'emplacement précis pour faciliter le retrouvé.</li>
                <li>Ajoutez des pièces jointes (photos, bordereaux) si nécessaire.</li>
            </ul>
        </div>
      </div>

      <div className="bg-slate-50 border border-slate-200 text-slate-600 p-8 rounded-xl mt-8">
          <div className="flex flex-col md:flex-row items-start md:items-center md:space-x-6 space-y-4 md:space-y-0">
             <div className="p-3 bg-white shadow-sm rounded-lg">
                <Settings className="text-slate-400" size={32} />
             </div>
             <div>
                 <h3 className="font-bold font-display text-lg uppercase mb-2 text-slate-800">Paramètres & Support</h3>
                 <p className="text-slate-500 text-sm">
                     Le mot de passe par défaut est <strong>1234</strong>. Vous pouvez le modifier à tout moment dans l'onglet Paramètres pour sécuriser l'accès à l'application.
                 </p>
             </div>
          </div>
          <div className="mt-6 pt-6 border-t border-slate-200 text-center md:text-right">
              <p className="text-xs text-slate-400 uppercase tracking-widest font-bold">
                  Application développée par Bouzid Cherif
              </p>
          </div>
      </div>
    </div>
  );
};
