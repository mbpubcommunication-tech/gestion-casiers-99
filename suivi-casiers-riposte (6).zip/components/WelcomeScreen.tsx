

import React, { useEffect, useState } from 'react';
import { Box, ArrowRight, Archive, Activity, Layers, ShieldCheck } from 'lucide-react'; // Added new icons

interface WelcomeScreenProps {
  onStart: () => void;
}

export const WelcomeScreen: React.FC<WelcomeScreenProps> = ({ onStart }) => {
  const [animate, setAnimate] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setAnimate(true);
    }, 100);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 to-indigo-950 flex items-center justify-center p-4 relative overflow-hidden">
      {/* Complex animated background shapes */}
      <div className={`absolute w-[600px] h-[600px] rounded-full bg-indigo-700 opacity-8 blur-3xl -top-40 -left-40 animate-float-1 ${animate ? 'opacity-8' : 'opacity-0'}`} style={{transitionDelay: '0.1s'}}></div>
      <div className={`absolute w-[700px] h-[700px] rounded-full bg-blue-600 opacity-6 blur-3xl -bottom-60 -right-60 animate-float-2 ${animate ? 'opacity-6' : 'opacity-0'}`} style={{animationDelay: '0.2s'}}></div>
      <div className={`absolute w-[500px] h-[500px] rounded-full bg-purple-700 opacity-4 blur-3xl top-1/2 left-1/4 -translate-x-1/2 -translate-y-1/2 animate-float-3 ${animate ? 'opacity-4' : 'opacity-0'}`} style={{animationDelay: '0.3s'}}></div>

      <div className={`
        bg-white/5 backdrop-blur-3xl border border-white/10 rounded-3xl shadow-2xl p-8 md:p-12 w-full max-w-4xl text-center z-10
        transition-all duration-1000 ease-out transform
        ${animate ? 'opacity-100 scale-100 translate-y-0' : 'opacity-0 scale-95 translate-y-10'}
      `}>
        {/* App Icon */}
        <div className={`inline-flex items-center justify-center w-32 h-32 rounded-3xl bg-gradient-to-br from-indigo-500 to-blue-600 shadow-xl mb-8
          ${animate ? 'animate-fade-in-up-bounce' : ''} transform hover:scale-105 transition-transform duration-300`}>
          <Box size={70} className="text-white drop-shadow-lg" />
        </div>

        {/* Title */}
        <h1 className="text-5xl md:text-6xl font-extrabold text-white mb-3 font-display tracking-tight drop-shadow-lg leading-tight">
          BIENVENUE SUR <br /><span className="animated-gradient-text">RIPOSTE CASIERS</span>
        </h1>
        <p className="text-xl md:text-2xl font-semibold text-slate-200 mb-8 max-w-xl mx-auto leading-relaxed font-inter">
            Gestion de stock <strong className='text-indigo-300'>intelligente et intuitive</strong>.
        </p>

        {/* Description */}
        <p className="text-base md:text-lg text-slate-300 mb-10 max-w-xl mx-auto leading-relaxed font-inter">
          Votre plateforme ultime pour une gestion de stock <strong className='text-indigo-200'>simplifiée et sécurisée</strong>.
          <br/>
          <strong className='font-bold text-indigo-200'>Stocker, Gérer, Suivre</strong> : Prenez le contrôle total de vos casiers.
          <br/>
          Notre application <strong className='text-indigo-200'>intuitive et fiable</strong> vous permet d'enregistrer les dépôts,
          mettre à jour les statuts et optimiser les emplacements avec efficacité.
        </p>

        {/* New: Feature Highlights Section */}
        <div className="mt-12 mb-10">
          <h2 className="text-2xl font-bold text-indigo-200 mb-6 font-display uppercase tracking-wide">Fonctionnalités Clés</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Feature Card 1 */}
            <div className="bg-white/10 p-5 rounded-xl border border-white/20 hover:border-indigo-400 transition-colors duration-200 flex flex-col items-center text-center">
              <Archive size={36} className="text-indigo-300 mb-3" />
              <h3 className="font-bold text-lg text-white mb-2">Archivage Intelligent</h3>
              <p className="text-sm text-slate-300">Historisez et gérez vos casiers terminés sans perdre l'information.</p>
            </div>
            {/* Feature Card 2 */}
            <div className="bg-white/10 p-5 rounded-xl border border-white/20 hover:border-blue-400 transition-colors duration-200 flex flex-col items-center text-center">
              <Activity size={36} className="text-blue-300 mb-3" />
              <h3 className="font-bold text-lg text-white mb-2">Suivi Proactif</h3>
              <p className="text-sm text-slate-300">Gardez un œil sur les statuts et les alertes importantes en temps réel.</p>
            </div>
            {/* Feature Card 3 */}
            <div className="bg-white/10 p-5 rounded-xl border border-white/20 hover:border-emerald-400 transition-colors duration-200 flex flex-col items-center text-center">
              <Layers size={36} className="text-emerald-300 mb-3" />
              <h3 className="font-bold text-lg text-white mb-2">Gestion Simplifiée</h3>
              <p className="text-sm text-slate-300">Une interface intuitive pour une administration des casiers sans effort.</p>
            </div>
            {/* Feature Card 4 */}
            <div className="bg-white/10 p-5 rounded-xl border border-white/20 hover:border-purple-400 transition-colors duration-200 flex flex-col items-center text-center">
              <ShieldCheck size={36} className="text-purple-300 mb-3" />
              <h3 className="font-bold text-lg text-white mb-2">Sécurité des Données</h3>
              <p className="text-sm text-slate-300">Vos informations sont protégées par un accès sécurisé par mot de passe.</p>
            </div>
          </div>
        </div>

        {/* Call to Action Button */}
        <button
          onClick={onStart}
          className="bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white font-bold py-4 px-10 rounded-full shadow-lg shadow-indigo-900/50 hover:shadow-blue-600/50 transition-all duration-300 flex items-center justify-center mx-auto group border border-indigo-400/50"
        >
          <span className="text-lg md:text-xl">DÉMARRER L'APPLICATION</span>
          <ArrowRight className="ml-3 transform group-hover:translate-x-2 transition-transform" size={24} />
        </button>

        {/* Developer Name */}
        <div className="mt-12 text-center">
            <p className="text-xs text-slate-400 uppercase tracking-widest font-bold">
                Développé avec passion par <span className="text-indigo-300">Bouzid Cherif</span>
            </p>
        </div>
      </div>

      {/* Custom Tailwind CSS keyframes */}
      <style>{`
        @keyframes float-1 {
          0%, 100% { transform: translate(0, 0) scale(1) rotate(0deg); }
          33% { transform: translate(25px, 15px) scale(1.02) rotate(5deg); }
          66% { transform: translate(-15px, -25px) scale(0.98) rotate(-5deg); }
        }
        @keyframes float-2 {
            0%, 100% { transform: translate(0, 0) scale(1) rotate(0deg); }
            33% { transform: translate(-20px, -15px) scale(0.97) rotate(-4deg); }
            66% { transform: translate(15px, 20px) scale(1.03) rotate(4deg); }
        }
        @keyframes float-3 {
            0%, 100% { transform: translate(-50%, -50%) scale(1) rotate(0deg); }
            33% { transform: translate(-48%, -52%) scale(1.01) rotate(3deg); }
            66% { transform: translate(-52%, -48%) scale(0.99) rotate(-3deg); }
        }
        @keyframes fade-in-up-bounce {
            0% { opacity: 0; transform: translateY(30px) scale(0.8); }
            60% { opacity: 1; transform: translateY(-5px) scale(1.05); }
            100% { transform: translateY(0) scale(1); }
        }
        .animate-float-1 { animation: float-1 18s infinite ease-in-out alternate; }
        .animate-float-2 { animation: float-2 20s infinite ease-in-out alternate; }
        .animate-float-3 { animation: float-3 16s infinite ease-in-out alternate; }
        .animate-fade-in-up-bounce { animation: fade-in-up-bounce 0.9s ease-out forwards; }

        /* New: Gradient Text Animation */
        @keyframes gradient-animation {
          0% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
        .animated-gradient-text {
          background: linear-gradient(90deg, #a78bfa, #818cf8, #38bdf8, #a78bfa); /* purple-400, indigo-400, sky-400, then repeat */
          background-size: 200% auto;
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          animation: gradient-animation 6s ease infinite;
        }
      `}</style>
    </div>
  );
};