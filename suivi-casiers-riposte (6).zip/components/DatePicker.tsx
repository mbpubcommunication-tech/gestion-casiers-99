
import React, { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import { Calendar as CalendarIcon, ChevronLeft, ChevronRight, X } from 'lucide-react';

interface DatePickerProps {
  label: string;
  value: string; // Format YYYY-MM-DD
  onChange: (date: string) => void;
  placeholder?: string;
  required?: boolean;
}

export const DatePicker: React.FC<DatePickerProps> = ({ label, value, onChange, placeholder, required }) => {
  const [showCalendar, setShowCalendar] = useState(false);
  const [currentMonth, setCurrentMonth] = useState(new Date()); // Month currently displayed in calendar
  const datePickerRef = useRef<HTMLDivElement>(null);

  // Parse value string to Date object for internal use
  const selectedDate = value ? new Date(value + 'T00:00:00') : null; // Add T00:00:00 to avoid timezone issues for YYYY-MM-DD

  useEffect(() => {
    if (selectedDate && selectedDate.toString() !== 'Invalid Date') {
      setCurrentMonth(selectedDate); // Sync calendar to selected date
    } else {
      setCurrentMonth(new Date()); // Reset to today's month if no valid date
    }
  }, [value]); // Only re-sync when value changes

  const daysInMonth = (date: Date) => new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  const firstDayOfMonth = (date: Date) => new Date(date.getFullYear(), date.getMonth(), 1).getDay(); // 0 for Sunday, 1 for Monday

  const getStartDay = (date: Date) => {
    const day = firstDayOfMonth(date);
    return day === 0 ? 6 : day - 1; // Convert Sunday (0) to 6 (end of week)
  };

  const weekdays = ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'];
  const monthNames = [
    'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin',
    'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'
  ];

  const calendarDays = useMemo(() => {
    const numDays = daysInMonth(currentMonth);
    const startDay = getStartDay(currentMonth);
    const prevMonthDays = daysInMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1, 1));

    const days: Array<{ date: Date; isCurrentMonth: boolean }> = [];

    // Days from previous month
    for (let i = startDay - 1; i >= 0; i--) {
      days.push({
        date: new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1, prevMonthDays - i),
        isCurrentMonth: false,
      });
    }

    // Days of current month
    for (let i = 1; i <= numDays; i++) {
      days.push({
        date: new Date(currentMonth.getFullYear(), currentMonth.getMonth(), i),
        isCurrentMonth: true,
      });
    }

    // Days from next month (to fill the grid)
    // Ensure the grid always has 6 rows (42 cells) for consistency
    const totalDays = days.length;
    const remainingCells = 42 - totalDays; 

    for (let i = 1; i <= remainingCells; i++) {
      days.push({
        date: new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, i),
        isCurrentMonth: false,
      });
    }

    return days;
  }, [currentMonth]);

  const goToPreviousMonth = useCallback(() => {
    setCurrentMonth(prev => new Date(prev.getFullYear(), prev.getMonth() - 1, 1));
  }, []);

  const goToNextMonth = useCallback(() => {
    setCurrentMonth(prev => new Date(prev.getFullYear(), prev.getMonth() + 1, 1));
  }, []);

  const isSameDay = (d1: Date, d2: Date) => {
    return d1.getFullYear() === d2.getFullYear() &&
           d1.getMonth() === d2.getMonth() &&
           d1.getDate() === d2.getDate();
  };

  const handleDayClick = (date: Date) => {
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    onChange(`${year}-${month}-${day}`);
    setShowCalendar(false);
  };

  // Close calendar when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (datePickerRef.current && !datePickerRef.current.contains(event.target as Node)) {
        setShowCalendar(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  return (
    <div className="relative" ref={datePickerRef}>
      <label className="text-xs font-bold text-slate-500 uppercase tracking-wider font-display">{label}</label>
      <div className="relative group mt-1">
        <input
          type="text"
          readOnly
          className={`w-full p-3 pl-10 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all cursor-pointer font-medium
            ${required && !value ? 'border-red-400 focus:ring-red-500' : ''}`}
          placeholder={placeholder || 'Sélectionner une date'}
          value={selectedDate && selectedDate.toString() !== 'Invalid Date' ? selectedDate.toLocaleDateString('fr-FR') : ''}
          onClick={() => setShowCalendar(true)}
          required={required}
        />
        <CalendarIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 group-hover:text-indigo-500 transition-colors pointer-events-none" size={18} />
      </div>

      {showCalendar && (
        <div className="absolute z-50 bg-white p-4 rounded-xl shadow-xl border border-slate-100 mt-2 w-80 animate-in zoom-in-95 duration-200">
          {/* Calendar Header */}
          <div className="flex items-center justify-between mb-4">
            <button onClick={goToPreviousMonth} className="p-2 rounded-full hover:bg-slate-100 transition-colors text-slate-600">
              <ChevronLeft size={20} />
            </button>
            <h3 className="text-lg font-bold text-slate-800 font-display">
              {monthNames[currentMonth.getMonth()]} {currentMonth.getFullYear()}
            </h3>
            <button onClick={goToNextMonth} className="p-2 rounded-full hover:bg-slate-100 transition-colors text-slate-600">
              <ChevronRight size={20} />
            </button>
          </div>

          {/* Weekday Headers */}
          <div className="grid grid-cols-7 gap-1 text-center text-xs font-semibold text-slate-500 mb-2">
            {weekdays.map(day => (
              <div key={day} className="py-1">{day}</div>
            ))}
          </div>

          {/* Calendar Grid */}
          <div className="grid grid-cols-7 gap-1">
            {calendarDays.map((dayObj, index) => {
              const { date, isCurrentMonth } = dayObj;
              const today = new Date();

              const dayClasses = `
                w-full h-8 flex items-center justify-center rounded-md text-sm cursor-pointer
                ${isCurrentMonth ? 'text-slate-800' : 'text-slate-400 opacity-60'}
                ${isSameDay(date, today) ? 'bg-indigo-100 text-indigo-700 font-bold border border-indigo-300' : 'hover:bg-slate-100'}
                ${selectedDate && isSameDay(date, selectedDate) && isCurrentMonth ? 'bg-indigo-600 text-white font-bold hover:bg-indigo-700' : ''}
                transition-colors duration-100
              `;

              return (
                <button
                  key={index}
                  type="button"
                  onClick={() => handleDayClick(date)}
                  className={dayClasses}
                  disabled={!isCurrentMonth} // Disable interaction for days outside current month
                >
                  {date.getDate()}
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
